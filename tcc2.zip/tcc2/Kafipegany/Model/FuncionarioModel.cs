﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kafipegany.Dal;
using Kafipegany.Entidades;

namespace Model
{
    public class FuncionarioModel
    {
        AcessoBanco bd;

        public void InserirFuncionario(tb_funcionario tb)
        {
            //
            try
            {
                //tratamento para quando haver um apostrofo no nome
                string mome = tb.Nm_funcionario.Replace("'", "''");

                //Conecta no banco
                bd = new AcessoBanco();
                bd.Conectar();

                //Faz o insert na Tabela 
                string comando = "INSERT INTO tb_funcionario(nm_nome,ds_cargo,dt_nascimento,cd_rg,cd_cpf,ds_telefone,ds_celular,cd_cep,nm_estado,nm_cidade," +
                    "ds_endereco,nm_bairro) VALUES('" + tb.Nm_funcionario + "','" + tb.Ds_cargo + "','" + tb.Dt_nascimento + "','" + tb.Cd_rg + "','" + tb.Cd_cpf + "'," +
                    "'" + tb.Ds_telefone + "','" + tb.Ds_celular + "','" + tb.Cd_cep + "','" + tb.Nm_estado + "','" + tb.Nm_cidade + "','" + tb.Ds_endereco + "','" + tb.Nm_bairro + "')";
                bd.ExecultarComandoSql(comando);
            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar cadastrar o Funcionário: " + ex.Message);
            }
            finally
            {
                bd = null;
            }
        }

        public void AtualizarFuncionario(tb_funcionario tb)
        {
            //
            try
            {
                //tratamento para quando haver um apostrofo no nome
                string mome = tb.Nm_funcionario.Replace("'", "''");

                //Conecta no banco
                bd = new AcessoBanco();
                bd.Conectar();

                //Faz o insert na Tabela 
                string comando = "UPDATE tb_usuario set nm_nome = '" + tb.Nm_funcionario + "',ds_cargo='" + tb.Ds_cargo + "', dt_nascimento='" + tb.Dt_nascimento + "', cd_rg='" + tb.Cd_rg + "', cd_cpf='" + tb.Cd_cpf + "', ds_telefone='" + tb.Ds_telefone + "', ds_celular='" + tb.Ds_celular + "', cd_cep='" + tb.Cd_cep + "', nm_estado='" + tb.Nm_estado + "', nm_cidade='" + tb.Nm_cidade + "', ds_endereco='" + tb.Ds_endereco + "', nm_bairro='" + tb.Nm_bairro + "' where cd_funcionario =" + tb.Cd_funcionario;
                bd.ExecultarComandoSql(comando);
            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar cadastrar o Funcionário: " + ex.Message);
            }
            finally
            {
                bd = null;
            }
        }

        public DataTable SelecionaTodosFuncionarios()
        {

            DataTable dt = new DataTable();
            try
            {
                bd = new AcessoBanco();
                bd.Conectar();
                dt = bd.RetDataTable("SELECT cd_funcionario, nm_nome,ds_cargo,dt_nascimento, cd_rg, cd_cpf, ds_telefone, ds_celular, cd_cep, nm_estado, nm_cidade, ds_endereco, nm_bairro from tb_funcionario");

            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar Selecionar todos os Funcionários: " + ex.Message);
            }
            finally
            {
                bd = null;
            }

            return dt;
        }

        public void ExcluirFuncionario(string funcionario)
        {
            try
            {


                //Conecta no banco
                bd = new AcessoBanco();
                bd.Conectar();

                //Faz o insert na Tabela 
                string comando = "DELETE FROM tb_funcionario where cd_funcionario = " + funcionario;
                bd.ExecultarComandoSql(comando);
            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar Excluir o Funcionário: " + ex.Message);
            }
            finally
            {
                bd = null;
            }
        }


        public void PesquisarFuncionario(string nm_funcionario)
        {
            try
            {
                //Conecta no banco
                bd = new AcessoBanco();
                bd.Conectar();
                string comando = "SELECT tb_funcionario where nm_funcionario = " + nm_funcionario;
                bd.ExecultarComandoSql(comando);
            }
            catch (Exception ex)
            {

                throw new Exception("Erro ao tentar Pesquisar: " + ex.Message);
            }
            finally
            {
                bd = null;
            }
        }
    }
}
