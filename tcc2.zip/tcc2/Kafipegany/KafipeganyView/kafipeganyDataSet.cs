﻿namespace KafipeganyView
{


    partial class kafipeganyDataSet
    {
    }
}
