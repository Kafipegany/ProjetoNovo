﻿namespace KafipeganyView
{
    partial class frmCadastrarQuarto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCadastrarQuarto));
            this.pnlTopo = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.GridQuarto = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtValor = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtcd = new System.Windows.Forms.TextBox();
            this.txtDescricao = new System.Windows.Forms.TextBox();
            this.txtNumeroQuarto = new System.Windows.Forms.TextBox();
            this.txtCapacidade = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnNovo = new System.Windows.Forms.Button();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnIconeMinimizar = new System.Windows.Forms.PictureBox();
            this.btnIconeEncerrar = new System.Windows.Forms.PictureBox();
            this.kafipeganyDataSet = new KafipeganyView.kafipeganyDataSet();
            this.tbquartoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tb_quartoTableAdapter = new KafipeganyView.kafipeganyDataSetTableAdapters.tb_quartoTableAdapter();
            this.cdquartoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nmquartoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vldiariaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nrcapacidadeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dsquartoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idreservaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dsstatusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlTopo.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridQuarto)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnIconeMinimizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnIconeEncerrar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kafipeganyDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbquartoBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlTopo
            // 
            this.pnlTopo.BackColor = System.Drawing.Color.Black;
            this.pnlTopo.Controls.Add(this.btnIconeMinimizar);
            this.pnlTopo.Controls.Add(this.btnIconeEncerrar);
            this.pnlTopo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTopo.Location = new System.Drawing.Point(0, 0);
            this.pnlTopo.Name = "pnlTopo";
            this.pnlTopo.Size = new System.Drawing.Size(800, 40);
            this.pnlTopo.TabIndex = 6;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Black;
            this.panel5.Controls.Add(this.GridQuarto);
            this.panel5.Controls.Add(this.panel1);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 40);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(800, 479);
            this.panel5.TabIndex = 8;
            // 
            // GridQuarto
            // 
            this.GridQuarto.AutoGenerateColumns = false;
            this.GridQuarto.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.GridQuarto.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.GridQuarto.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GridQuarto.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.GridQuarto.ColumnHeadersHeight = 50;
            this.GridQuarto.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cdquartoDataGridViewTextBoxColumn,
            this.nmquartoDataGridViewTextBoxColumn,
            this.vldiariaDataGridViewTextBoxColumn,
            this.nrcapacidadeDataGridViewTextBoxColumn,
            this.dsquartoDataGridViewTextBoxColumn,
            this.idreservaDataGridViewTextBoxColumn,
            this.dsstatusDataGridViewTextBoxColumn});
            this.GridQuarto.DataSource = this.tbquartoBindingSource;
            this.GridQuarto.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GridQuarto.EnableHeadersVisualStyles = false;
            this.GridQuarto.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(48)))), ((int)(((byte)(58)))));
            this.GridQuarto.Location = new System.Drawing.Point(382, 0);
            this.GridQuarto.Name = "GridQuarto";
            this.GridQuarto.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(48)))), ((int)(((byte)(58)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GridQuarto.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.GridQuarto.RowHeadersVisible = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Century Gothic", 12F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(48)))), ((int)(((byte)(58)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White;
            this.GridQuarto.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.GridQuarto.Size = new System.Drawing.Size(418, 479);
            this.GridQuarto.TabIndex = 78;
            this.GridQuarto.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GridQuarto_CellContentClick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.Controls.Add(this.txtValor);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtcd);
            this.panel1.Controls.Add(this.txtDescricao);
            this.panel1.Controls.Add(this.txtNumeroQuarto);
            this.panel1.Controls.Add(this.txtCapacidade);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(382, 479);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // txtValor
            // 
            this.txtValor.Enabled = false;
            this.txtValor.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtValor.Location = new System.Drawing.Point(152, 214);
            this.txtValor.Name = "txtValor";
            this.txtValor.Size = new System.Drawing.Size(88, 26);
            this.txtValor.TabIndex = 112;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Cambria", 14F);
            this.label3.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label3.Location = new System.Drawing.Point(33, 214);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 22);
            this.label3.TabIndex = 111;
            this.label3.Text = "Valor Diária";
            // 
            // txtcd
            // 
            this.txtcd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
            this.txtcd.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtcd.Enabled = false;
            this.txtcd.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtcd.Location = new System.Drawing.Point(280, 134);
            this.txtcd.Name = "txtcd";
            this.txtcd.Size = new System.Drawing.Size(76, 19);
            this.txtcd.TabIndex = 110;
            // 
            // txtDescricao
            // 
            this.txtDescricao.Enabled = false;
            this.txtDescricao.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtDescricao.Location = new System.Drawing.Point(34, 277);
            this.txtDescricao.Name = "txtDescricao";
            this.txtDescricao.Size = new System.Drawing.Size(340, 26);
            this.txtDescricao.TabIndex = 99;
            // 
            // txtNumeroQuarto
            // 
            this.txtNumeroQuarto.Enabled = false;
            this.txtNumeroQuarto.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtNumeroQuarto.Location = new System.Drawing.Point(203, 109);
            this.txtNumeroQuarto.Name = "txtNumeroQuarto";
            this.txtNumeroQuarto.Size = new System.Drawing.Size(71, 26);
            this.txtNumeroQuarto.TabIndex = 98;
            // 
            // txtCapacidade
            // 
            this.txtCapacidade.Enabled = false;
            this.txtCapacidade.Font = new System.Drawing.Font("Cambria", 12F);
            this.txtCapacidade.Location = new System.Drawing.Point(229, 165);
            this.txtCapacidade.Name = "txtCapacidade";
            this.txtCapacidade.Size = new System.Drawing.Size(45, 26);
            this.txtCapacidade.TabIndex = 97;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cambria", 14F);
            this.label2.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label2.Location = new System.Drawing.Point(30, 252);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(178, 22);
            this.label2.TabIndex = 96;
            this.label2.Text = "Descrição do Quarto:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cambria", 14F);
            this.label1.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label1.Location = new System.Drawing.Point(30, 165);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(193, 22);
            this.label1.TabIndex = 95;
            this.label1.Text = "Capacidade do Quarto:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Cambria", 14F);
            this.label6.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.label6.Location = new System.Drawing.Point(30, 109);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(167, 22);
            this.label6.TabIndex = 94;
            this.label6.Text = "Número do Quarto:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.panel3.Controls.Add(this.btnSair);
            this.panel3.Controls.Add(this.btnNovo);
            this.panel3.Controls.Add(this.btnSalvar);
            this.panel3.Controls.Add(this.btnExcluir);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 379);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(382, 100);
            this.panel3.TabIndex = 92;
            // 
            // btnSair
            // 
            this.btnSair.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSair.BackgroundImage")));
            this.btnSair.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSair.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSair.FlatAppearance.BorderSize = 0;
            this.btnSair.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnSair.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSair.ForeColor = System.Drawing.Color.Transparent;
            this.btnSair.Location = new System.Drawing.Point(291, 17);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(51, 66);
            this.btnSair.TabIndex = 67;
            this.btnSair.UseVisualStyleBackColor = true;
            // 
            // btnNovo
            // 
            this.btnNovo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnNovo.BackgroundImage")));
            this.btnNovo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnNovo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNovo.FlatAppearance.BorderSize = 0;
            this.btnNovo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnNovo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnNovo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNovo.Location = new System.Drawing.Point(34, 15);
            this.btnNovo.Name = "btnNovo";
            this.btnNovo.Size = new System.Drawing.Size(72, 71);
            this.btnNovo.TabIndex = 66;
            this.btnNovo.UseVisualStyleBackColor = true;
            this.btnNovo.Click += new System.EventHandler(this.btnNovo_Click);
            // 
            // btnSalvar
            // 
            this.btnSalvar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSalvar.BackgroundImage")));
            this.btnSalvar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSalvar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSalvar.Enabled = false;
            this.btnSalvar.FlatAppearance.BorderSize = 0;
            this.btnSalvar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnSalvar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnSalvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalvar.ForeColor = System.Drawing.Color.Transparent;
            this.btnSalvar.Location = new System.Drawing.Point(134, 20);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(52, 61);
            this.btnSalvar.TabIndex = 64;
            this.btnSalvar.UseVisualStyleBackColor = true;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // btnExcluir
            // 
            this.btnExcluir.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnExcluir.BackgroundImage")));
            this.btnExcluir.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnExcluir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExcluir.FlatAppearance.BorderSize = 0;
            this.btnExcluir.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnExcluir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnExcluir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcluir.Location = new System.Drawing.Point(208, 20);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(61, 61);
            this.btnExcluir.TabIndex = 65;
            this.btnExcluir.UseVisualStyleBackColor = true;
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gray;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(382, 61);
            this.panel2.TabIndex = 62;
            // 
            // btnIconeMinimizar
            // 
            this.btnIconeMinimizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnIconeMinimizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIconeMinimizar.Image = ((System.Drawing.Image)(resources.GetObject("btnIconeMinimizar.Image")));
            this.btnIconeMinimizar.Location = new System.Drawing.Point(714, 0);
            this.btnIconeMinimizar.Name = "btnIconeMinimizar";
            this.btnIconeMinimizar.Size = new System.Drawing.Size(40, 40);
            this.btnIconeMinimizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnIconeMinimizar.TabIndex = 2;
            this.btnIconeMinimizar.TabStop = false;
            this.btnIconeMinimizar.Click += new System.EventHandler(this.btnIconeMinimizar_Click);
            // 
            // btnIconeEncerrar
            // 
            this.btnIconeEncerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnIconeEncerrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIconeEncerrar.Image = ((System.Drawing.Image)(resources.GetObject("btnIconeEncerrar.Image")));
            this.btnIconeEncerrar.Location = new System.Drawing.Point(760, 0);
            this.btnIconeEncerrar.Name = "btnIconeEncerrar";
            this.btnIconeEncerrar.Size = new System.Drawing.Size(40, 40);
            this.btnIconeEncerrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnIconeEncerrar.TabIndex = 1;
            this.btnIconeEncerrar.TabStop = false;
            this.btnIconeEncerrar.Click += new System.EventHandler(this.btnIconeEncerrar_Click);
            // 
            // kafipeganyDataSet
            // 
            this.kafipeganyDataSet.DataSetName = "kafipeganyDataSet";
            this.kafipeganyDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbquartoBindingSource
            // 
            this.tbquartoBindingSource.DataMember = "tb_quarto";
            this.tbquartoBindingSource.DataSource = this.kafipeganyDataSet;
            // 
            // tb_quartoTableAdapter
            // 
            this.tb_quartoTableAdapter.ClearBeforeFill = true;
            // 
            // cdquartoDataGridViewTextBoxColumn
            // 
            this.cdquartoDataGridViewTextBoxColumn.DataPropertyName = "cd_quarto";
            this.cdquartoDataGridViewTextBoxColumn.HeaderText = "ID";
            this.cdquartoDataGridViewTextBoxColumn.Name = "cdquartoDataGridViewTextBoxColumn";
            this.cdquartoDataGridViewTextBoxColumn.Width = 35;
            // 
            // nmquartoDataGridViewTextBoxColumn
            // 
            this.nmquartoDataGridViewTextBoxColumn.DataPropertyName = "nm_quarto";
            this.nmquartoDataGridViewTextBoxColumn.HeaderText = "Quarto";
            this.nmquartoDataGridViewTextBoxColumn.Name = "nmquartoDataGridViewTextBoxColumn";
            // 
            // vldiariaDataGridViewTextBoxColumn
            // 
            this.vldiariaDataGridViewTextBoxColumn.DataPropertyName = "vl_diaria";
            this.vldiariaDataGridViewTextBoxColumn.HeaderText = "Valor";
            this.vldiariaDataGridViewTextBoxColumn.Name = "vldiariaDataGridViewTextBoxColumn";
            // 
            // nrcapacidadeDataGridViewTextBoxColumn
            // 
            this.nrcapacidadeDataGridViewTextBoxColumn.DataPropertyName = "nr_capacidade";
            this.nrcapacidadeDataGridViewTextBoxColumn.HeaderText = "Capacidade";
            this.nrcapacidadeDataGridViewTextBoxColumn.Name = "nrcapacidadeDataGridViewTextBoxColumn";
            this.nrcapacidadeDataGridViewTextBoxColumn.Width = 150;
            // 
            // dsquartoDataGridViewTextBoxColumn
            // 
            this.dsquartoDataGridViewTextBoxColumn.DataPropertyName = "ds_quarto";
            this.dsquartoDataGridViewTextBoxColumn.HeaderText = "ds_quarto";
            this.dsquartoDataGridViewTextBoxColumn.Name = "dsquartoDataGridViewTextBoxColumn";
            this.dsquartoDataGridViewTextBoxColumn.Visible = false;
            // 
            // idreservaDataGridViewTextBoxColumn
            // 
            this.idreservaDataGridViewTextBoxColumn.DataPropertyName = "id_reserva";
            this.idreservaDataGridViewTextBoxColumn.HeaderText = "id_reserva";
            this.idreservaDataGridViewTextBoxColumn.Name = "idreservaDataGridViewTextBoxColumn";
            this.idreservaDataGridViewTextBoxColumn.Visible = false;
            // 
            // dsstatusDataGridViewTextBoxColumn
            // 
            this.dsstatusDataGridViewTextBoxColumn.DataPropertyName = "ds_status";
            this.dsstatusDataGridViewTextBoxColumn.HeaderText = "ds_status";
            this.dsstatusDataGridViewTextBoxColumn.Name = "dsstatusDataGridViewTextBoxColumn";
            this.dsstatusDataGridViewTextBoxColumn.Visible = false;
            // 
            // frmCadastrarQuarto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 519);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.pnlTopo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(675, 280);
            this.Name = "frmCadastrarQuarto";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "frmCadastrarQuarto";
            this.Load += new System.EventHandler(this.frmCadastrarQuarto_Load);
            this.pnlTopo.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GridQuarto)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnIconeMinimizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnIconeEncerrar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kafipeganyDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbquartoBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTopo;
        private System.Windows.Forms.PictureBox btnIconeMinimizar;
        private System.Windows.Forms.PictureBox btnIconeEncerrar;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView GridQuarto;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtValor;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtcd;
        private System.Windows.Forms.TextBox txtDescricao;
        private System.Windows.Forms.TextBox txtNumeroQuarto;
        private System.Windows.Forms.TextBox txtCapacidade;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnNovo;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.Button btnExcluir;
        private System.Windows.Forms.Panel panel2;
        private kafipeganyDataSet kafipeganyDataSet;
        private System.Windows.Forms.BindingSource tbquartoBindingSource;
        private kafipeganyDataSetTableAdapters.tb_quartoTableAdapter tb_quartoTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn cdquartoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nmquartoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vldiariaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nrcapacidadeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dsquartoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idreservaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dsstatusDataGridViewTextBoxColumn;
    }
}