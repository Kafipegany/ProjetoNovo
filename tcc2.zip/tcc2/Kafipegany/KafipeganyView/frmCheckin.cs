﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KafipeganyView
{
    public partial class frmCheckin : Form
    {
        public frmCheckin()
        {
            InitializeComponent();
        }

        private void frmCheckin_Load(object sender, EventArgs e)
        {
            

        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("O Checkin foi Realizado com sucesso!", "Inserido com Sucesso!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            LimparCampos();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            HabilitarCampos();
            btnSalvar.Enabled= true;
            
        }
        private void HabilitarCampos()
        {
           cbQuarto.Enabled = true;
            cbQuarto.Enabled = true;
           dtSaida.Enabled = true;
           comboBox1.Enabled = true;
        }

        private void LimparCampos()
        {

            cbQuarto.Text = "";
            txtDescricao.Text = "";
            comboBox1.Text = "";
        }

        private void Desabilitar()
        {
            cbQuarto.Enabled = false;
            txtDescricao.Enabled = false;
            dtSaida.Enabled = false;
            comboBox1.Enabled = false;
        }

        private void btnIconeEncerrar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
