﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KafipeganyView
{
    public partial class frmMenu : Form
    {
        public frmMenu()
        {
            InitializeComponent();
        }
        private void customizeDesign()
        {
            pnlCadastros.Visible = false;
            pnlProduto.Visible = false;
            pnlReserva.Visible = false;
            pnlCheck.Visible = false;
            pnlRelatorios.Visible = false;

        }
        private void hideSubMenu()
        {
            if (pnlCadastros.Visible == true)
            {
                pnlCadastros.Visible = false;
            }
            if (pnlProduto.Visible == true)
            {
                pnlProduto.Visible = false;
            }
            if (pnlReserva.Visible == true)
            {
                pnlReserva.Visible = false;
            }
            if (pnlCheck.Visible == true)
            {
                pnlCheck.Visible = false;
            }
            if (pnlRelatorios.Visible == true)
            {
                pnlRelatorios.Visible = false;
            }
        }
        private void showSubMenu(Panel SubMenu)
        {
            if (SubMenu.Visible == false)
            {
                hideSubMenu();
                SubMenu.Visible = true;
            }
            else
                SubMenu.Visible = false;
        }

        private void btnCadastros_Click(object sender, EventArgs e)
        {
            showSubMenu(pnlCadastros);
        }

        private void btnProdutos_Click(object sender, EventArgs e)
        {
            showSubMenu(pnlProduto);
        }

        private void btnReserva_Click(object sender, EventArgs e)
        {
            showSubMenu(pnlReserva);
        }

        private void btnChekInOut_Click(object sender, EventArgs e)
        {
            showSubMenu(pnlCheck);
        }

        private void btnRelatorios_Click(object sender, EventArgs e)
        {
            showSubMenu(pnlRelatorios);
        }

        private void btnIconeMinimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnIconeEncerrar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSlide3_Click(object sender, EventArgs e)
        {
            if (pnlMenu.Width == 80)
            {
                pnlMenu.Width = 250;
                btnSlide.Visible = true;
                btnSlide3.Visible = false;
            }
        }

        private void btnSlide_Click(object sender, EventArgs e)
        {
            if (pnlMenu.Width == 250)
            {
                pnlMenu.Width = 80;
                btnSlide.Visible = false;
                btnSlide3.Visible = true;
            }
        }

        private void btnCadastroFuncionario_Click(object sender, EventArgs e)
        {
            frmCadastrarfuncionario frm = new frmCadastrarfuncionario();
            frm.Show();
        }

        private void btnCadastrosHospedes_Click(object sender, EventArgs e)
        {
            frmCadastrarHospede frm = new frmCadastrarHospede();
            frm.Show();
        }

        private void btnCadastrosQuartos_Click(object sender, EventArgs e)
        {
            frmCadastrarQuarto frm = new frmCadastrarQuarto();
            frm.Show();
        }

        private void btnNewProduto_Click(object sender, EventArgs e)
        {
            frmProduto frm = new frmProduto();
            frm.Show();
        }

        private void btnProdutoEstoque_Click(object sender, EventArgs e)
        {
            frmEstoque frm = new frmEstoque();
            frm.Show();
        }

        private void btnReservaNewReserva_Click(object sender, EventArgs e)
        {
            frmReserva frm = new frmReserva();
            frm.Show();
        }

        private void btnCheckIn_Click(object sender, EventArgs e)
        {
            frmCheckin frm = new frmCheckin();
            frm.Show();
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

   

    }
}
