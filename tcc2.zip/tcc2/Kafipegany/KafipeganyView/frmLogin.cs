﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Kafipegany.Entidades;
using Kafipegany.Model;
using MySql.Data.MySqlClient;

namespace KafipeganyView
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
            pnlLogin.Visible = false;
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            ChamarLogin();
        }
        private void ChamarLogin()
        {
            string conexao = "server=localhost;user id=root;password=usbw; database=kafipegany;";
            var connection = new MySqlConnection(conexao);
            String sql = "select * from  tb_usuario where nm_username = '" + txtUsername.Text + "' and cd_senha = '" + txtSenha.Text + "'";

            MySqlCommand execultaxmdsql = new MySqlCommand(sql, connection);

            execultaxmdsql.Parameters.AddWithValue("nm_username", txtUsername.Text);
            execultaxmdsql.Parameters.AddWithValue("cd_senha", txtSenha.Text);



            connection.Open();

            
            MySqlDataReader dados = execultaxmdsql.ExecuteReader();
            if (txtUsername.Text != ""  )
            {
                if(txtSenha.Text != "")
                {
                    if (dados.Read())
                    {
                        string nivel_acesso = dados.GetString("nm_Cargo");
                        if (nivel_acesso.Equals("Administrador"))
                        {
                            frmMenu frm = new frmMenu();
                            MessageBox.Show("O Usuário foi Logado com sucesso!", "Login Valido!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            frm.Show();
                            LimparCampos();
                            
                        }
                        else if (nivel_acesso.Equals("Gerente"))
                        {
                            frmMenu frm = new frmMenu();
                            frm.btnRelatorios.Enabled = false;
                            frm.Show();
                            LimparCampos();
                           
                        }
                        else if (nivel_acesso.Equals("Recepcionista"))
                        {
                            frmMenu frm = new frmMenu();
                            frm.btnRelatorios.Enabled  = false;
                            frm.btnCadastroFuncionario.Enabled = false;
                            frm.btnCadastrosQuartos.Enabled = false;
                            frm.btnNewProduto.Enabled = false;
                            frm.Show();
                            LimparCampos();
                            


                        }
                    }
                    else
                    {
                        MessageBox.Show("O usuário não foi encontrado!", "Login Inválido!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtUsername.Focus();
                        connection.Close();
                    }
                }
                else
                {
                    MessageBox.Show("Preencha o campo de Senha e tente novamente!", "Login Inválido!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtSenha.Focus();
                }
            }
           
            else
            {
                MessageBox.Show("Preencha o campo de Nome e tente novamente!", "Login Inválido!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
         

        }
        private void LimparCampos()
        {
            txtUsername.Text = "";
            txtSenha.Text = "";
            
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmCadastrarUsuario form = new frmCadastrarUsuario();
            form.Show();
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            pnlLogin.Location = new Point(this.Width / 2 - 183, this.Height / 2 - 229);
            pnlLogin.Visible = true;
        }

        private void btnIconeMinimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnIconeEncerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void frmLogin_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
               
                ChamarLogin();
            }
        }

       

    }
}
