﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kafipegany.Entidades
{
    public class tb_produto
    {
        private int cd_produto;
        private string nm_produto;
        private string ds_produto;
        private string vl_produto;
        private string qt_produto;
        private string qt_minima;

        public int Cd_produto { get => cd_produto; set => cd_produto = value; }
        public string Nm_produto { get => nm_produto; set => nm_produto = value; }
        public string Ds_produto { get => ds_produto; set => ds_produto = value; }
        public string Vl_produto { get => vl_produto; set => vl_produto = value; }
        public string Qt_produto { get => qt_produto; set => qt_produto = value; }
        public string Qt_minima { get => qt_minima; set => qt_minima = value; }
    }
}
